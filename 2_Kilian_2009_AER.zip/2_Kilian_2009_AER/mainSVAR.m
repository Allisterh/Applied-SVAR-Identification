% Kilian_2009_AER.m
% =======================================================================
% Partial replication of results in Kilian (2009, AER):
% "Not All Oil Price Shocks Are Alike: 
%   Disentangling Demand and Supply Shocks in the Crude Oil Market"
%
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(50)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot,'VAR'));
addpath(fullfile(toolboxroot,'Figure'));
addpath(fullfile(toolboxroot,'Stats'));
addpath(fullfile(toolboxroot,'Utils'));
addpath(fullfile(toolboxroot,'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

% Data and results folders
datafile  = fullfile(fileparts(mfilename('fullpath')),'data','data.txt');
resdir    = fullfile(fileparts(mfilename('fullpath')),'results');
if ~exist(resdir,'dir')
    mkdir(resdir);
end

%% 1. LOAD DATA
% -----------------------------------------------------------------------
% Columns of data.txt (no header): 
% 1 = % change in global crude oil production.
% 2 = index of real economic activity.
% 3 = real oil price (log).
% Sample: 1973M1 - 2007M12.

% Load data
y = readmatrix(datafile);

% Specify inputs
p   = 24;  % lag length
hor = 20;  % impulse horizon

vnames = {'Oil Production','World REA','Real Oil Price'}; % Variable names
snames = {'Oil Supply Shock','Aggregate Demand Shock','Oil-Specific Demand Shock'}; % Shock names

%% 2. FIGURE 1: DATA PLOT
% -----------------------------------------------------------------------
% Three monthly series: oil production growth, REA index, real oil price.

% Details for 'DatesPlot'
firstdate = 1973 + 1/12; % Sample starts 1973:M2
nticks = 6;              % Number of dates to display
[T,n] = size(y);         % Number of time periods

figure;
FigSize(22, 10)
for ii = 1:n
subplot(1, n, ii)
    plot(y(:, ii), 'LineWidth', 2, 'Color', pantone('Blue'));
    title(vnames{ii}, 'FontSize', 12);
    DatesPlot(firstdate, T, nticks, 'm')
    set(gca, 'FontSize', 11); 
    grid on;
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure1_Data'))
disp('Figure 1 (data) saved.')

%% 3. VAR ESTIMATION
% -----------------------------------------------------------------------
VARopt           = VARoption;
VARopt.ident     = 'short';   % Short-run zero restrictions (recursive)
VARopt.nsteps    = hor;       % Impulse horizon
VARopt.inference = 1;         % Bootstrap CIs
VARopt.mult      = 500;       % Display boostrap update
VARopt.vnames    = vnames;    % Variable names

disp('Estimating reduced-form VAR and identifying SVAR ...')
VAR = VARmodel(y,p,1,VARopt);

%% 3. SIGN FLIP + CUMULATION OF THE PRODUCTION RESPONSE
% -----------------------------------------------------------------------
% Kilian does two things outside of the toolbox's capabilities:
%   (a) Sign flip: considers a negative oil supply shock (positive price
%       response), so multiply shock-1 IRFs by -1.
%   (b) Cumulation: oil production enters the VAR in growth rates, so
%       accumulate the level response for variable 1 across all shocks.
% Both are permissible because the SVAR is linear.

IR    = VAR.IR;                        % nsteps x nvar x nvar
IRall = VAR.IRall;                     % nsteps x nvar x nvar x ndraws

% a) Flip sign of oil supply shock (column 1)
IR(:,:,1)      = -IR(:,:,1);
IRall(:,:,1,:) = -IRall(:,:,1,:);

% b) Cumulate oil production response (row 1) for all shocks
IR(:,1,:)      = cumsum(IR(:,1,:),1);
IRall(:,1,:,:) = cumsum(IRall(:,1,:,:),1);

%% 4. FIGURE 2: STRUCTURAL SHOCKS
% -----------------------------------------------------------------------
% Historical evolution of the three identified structural shocks,
% averaged to annual frequency as in his paper. Note that the data is from
% 1973:M2-2007:M12, he uses 24 lags, giving 32 years starting from 1976.

% Recover the structural shocks
eps = VAR.B \ VAR.resid';

% Transform to annual by taking appropriate average
dates          = 1976:1:2007;
T2             = length(dates);
annual_shocks  = zeros(n,T2);
for t = 1:T2
    annual_shocks(:,t) = mean(eps(:, 12*(t-1)+1 : 12*(t-1)+12), 2);
end

% Plot
figure('Name','Figure 2: Kilian (2009, AER) -- structural shocks, 1976-2007');
FigSize(22, 10)
for i = 1:n
    subplot(3,1,i)
    plot(annual_shocks(i,:), '-k', 'LineWidth', 2)
    title(snames{ii}, 'FontSize', 12);
    DatesPlot(dates(1), T2, nticks, 'y')
    set(gca, 'FontSize', 11); 
    grid on;
    SetAxesDual(gca);
end
savefig(gcf, fullfile(resdir,'Figure2.fig'));
SaveFigure(fullfile(resdir,'Figure2'));

%% 5. FIGURE 3: IMPULSE RESPONSES
% -----------------------------------------------------------------------
% Get the new 68% CI bands (they change after accumulation)
% IRlo = squeeze(prctile(IRall, 16, 4));  % This is percentile around bootstrap mean IRF. Doesn't guarantee the OLS IRF to be in the center. 
% IRhi = squeeze(prctile(IRall, 84, 4));

IRstd = squeeze(std(IRall, 0, 4));   % We therefore take a short-cut instead
IRlo  = IR - IRstd;
IRhi  = IR + IRstd;

% Plot
ax = [1 hor -25 15; 1 hor -5 10; 1 hor -6 11]; % axis limits
figure('Name','Figure 3: Kilian (2009, AER) -- responses to a 1-std-dev structural shock');
FigSize(22, 18)
s = 0; % Counter for plots
for j = 1:n       % columns: shock
    for i = 1:n   % rows: variable
        s = s+1;
        subplot(n,n,s)
        plot(1:hor, squeeze(IR(:,i,j)), '-b',  'LineWidth', 2);  
        hold on
            plot(1:hor, squeeze(IRlo(:,i,j)),  '--b', 'LineWidth', 1)
            plot(1:hor, squeeze(IRhi(:,i,j)),  '--b', 'LineWidth', 1)
            plot([1 hor], [0 0], '-k', 'LineWidth', 0.5)
            axis(ax(i,:))
            grid on;
        hold off

            if j == 1
                title(vnames{i})
            end
            if i == 1
                ylabel(snames{j}, 'FontWeight', 'bold');
            end
    end
end
savefig(gcf, fullfile(resdir,'Figure3.fig'));
SaveFigure(fullfile(resdir,'Figure3'));

%% 6. FIGURE 4: HISTORICAL DECOMPOSITION
% -----------------------------------------------------------------------
% Cumulative contribution of each structural shock to the historical path
% of the real price of crude oil (variable 3).

% Inputs
var_oil = 3; % Oil price

% Plot
titles = { ...
    'Cumulative effect of oil supply shock on real price of crude oil', ...
    'Cumulative effect of economic activity shock on real price of crude oil', ...
    'Cumulative effect of oil-specific demand shock on real price of crude oil'};

figure('Name','Figure 4: Kilian (2009, AER) -- historical decomposition of real oil price');
FigSize(22, 10)
for j = 1:n
    HDj = VAR.HD.shock(:, j, var_oil);
    subplot(3,1,j)
    plot(HDj, '-b', 'LineWidth', 2);  hold on
    DatesPlot(firstdate, T, nticks, 'm')
    plot(zeros(T,1), '-k', 'LineWidth', 0.5)
    axis([1 T -100 100])
    title(titles{j}, 'FontSize', 12);
    hold off
end
savefig(gcf, fullfile(resdir,'Figure4.fig'));
SaveFigure(fullfile(resdir,'Figure4'));

disp('Done. Figures saved to results/.')