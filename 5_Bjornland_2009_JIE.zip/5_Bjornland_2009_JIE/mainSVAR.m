% =======================================================================
% Partial replication of Bjornland (2009, JIE):
% "Monetary policy and exchange rate overshooting: Dornbusch was right
%  after all"
%
% Estimates a 5-variable open-economy VAR for Australia and New Zealand.
% Three identification schemes are compared:
%   (1) Blanchard-Quah long-run: MP shock has no permanent effect on RER.
%   (2) Cholesky ordering 1: interest rate (i) ordered before RER.
%   (3) Cholesky ordering 2: RER ordered before interest rate (i).
%
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot, 'VAR'));
addpath(fullfile(toolboxroot, 'Figure'));
addpath(fullfile(toolboxroot, 'Stats'));
addpath(fullfile(toolboxroot, 'Utils'));
addpath(fullfile(toolboxroot, 'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

datadir = fullfile(fileparts(mfilename('fullpath')), 'data');
resdir  = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir, 'dir')
    mkdir(resdir); 
end    

%% 1. CONTROLS
% -----------------------------------------------------------------------
% Specify inputs
p = 3;    % lag length 
detc = 2;  % Specify a constant and linear trend in the model
hor = 25;   % IRF horizon

% State order of interest and rer as we will swap them later
mp_idx  = 4;   % interest rate 
rer_idx = 5;   % real exchange rate

% General VARopt templates for each identification scheme
VARopt_LR           = VARoption;
VARopt_LR.ident     = 'long';   % Blanchard-Quah long-run zero restriction
VARopt_LR.nsteps    = hor;
VARopt_LR.inference = 0;

VARopt_SR           = VARoption;
VARopt_SR.ident     = 'short';  % Recursive short-run zero restriction
VARopt_SR.nsteps    = hor;
VARopt_SR.inference = 0;


%% 2. AUSTRALIA: DATA
% -----------------------------------------------------------------------
% 5 variables ordered as [rtwi, log(GDP), Aldp, r, d(log(RERinv))].
% Sample: 1982:Q1 -- 2004:Q4 (startRow = 17).

raw      = readcell(fullfile(datadir, 'bjornland_aus_Data.xlsx'), 'Sheet', 'Sheet1', 'Range', 'A5:M114');
varnames = raw(2, 2:end);
data     = cellfun(@double, raw(17:end, 2:end));
getcol   = @(name) data(:, strcmpi(name, varnames));

raw_aus = [getcol('rtwi'), log(getcol('GDP')), getcol('Aldp'), getcol('r'), log(getcol('RERinv'))];
y_aus   = [raw_aus(2:end, 1:4), diff(raw_aus(:, 5))]; % Uses rer growth

%% 3. AUSTRALIA: LONG-RUN IDENTIFICATION
% -----------------------------------------------------------------------
% Estimate VAR
VAR = VARmodel(y_aus, p, detc, VARopt_LR);  

% Two changes to IRFs:
% (a) normalize to a 1pp rate rise on impact
% (b) cumulate RER growth to get level response
IR  = VAR.IR;
IR = IR./IR(1,mp_idx,mp_idx);% normalize
IR(:,rer_idx,:) = cumsum(IR(:, rer_idx, :), 1);  % cumulate 

% Extract interest and RER for plots later on
aus_lr_rate = squeeze(IR(:, mp_idx,  mp_idx));   % interest rate response
aus_lr_rer  = squeeze(IR(:, rer_idx, mp_idx));   % RER response
disp('Australia (long-run) done.')


%% 4. AUSTRALIA: CHOLESKY IDENTIFICATION
% -----------------------------------------------------------------------
% Ordering 1: i at position 4, RER at position 5 (standard recursive).
VAR  = VARmodel(y_aus, p, detc, VARopt_SR);

% Change IRFs
IR   = VAR.IR;
IR(:, rer_idx, :) = cumsum(IR(:, rer_idx, :), 1);   % cumulate RER growth to level
IR   = IR ./ IR(1, mp_idx, mp_idx);                  % normalize to 1pp rate rise

% Extract interest rate and RER responses for plots
aus_ch1_rate = squeeze(IR(:, mp_idx,  mp_idx));   % interest rate response
aus_ch1_rer  = squeeze(IR(:, rer_idx, mp_idx));   % RER response

% Ordering 2: swap positions 4 and 5 so RER precedes i.
% Re-index: RER is now at position 4, rate at position 5.
y_aus_swap = [y_aus(:, 1:3)  y_aus(:, rer_idx)  y_aus(:, mp_idx)];

% Estimate VAR
VAR  = VARmodel(y_aus_swap, p, detc, VARopt_SR);

% Change IRFs
IR   = VAR.IR;
IR(:, 4, :) = cumsum(IR(:, 4, :), 1);   % cumulate RER (now at position 4)
IR   = IR ./ IR(1, 5, 5);               % normalize: rate is now at position 5

% Extract interest rate and RER responses for plots
aus_ch2_rate = squeeze(IR(:, 5, 5));   % interest rate response
aus_ch2_rer  = squeeze(IR(:, 4, 5));   % RER response
disp('Australia (Cholesky) done.')


%% 5. NEW ZEALAND: DATA
% -----------------------------------------------------------------------
% Same 5-variable system and sample dates as Australia, using NZ series.
% Sheet 'varN2'; sample: 1982:Q1 -- 2004:Q4 (startRow = 17).
raw      = readcell(fullfile(datadir, 'bjornland_nz_Data.xlsx'), 'Sheet', 'varN2', 'Range', 'A5:O114');
varnames = raw(2, 2:end);
data     = cellfun(@double, raw(17:end, 2:end));
getcol   = @(name) data(:, strcmpi(name, varnames));

raw_nz = [getcol('rtwi'), log(getcol('GDP')), getcol('Aldp'), getcol('r'), log(getcol('RERinv'))];
y_nz   = [raw_nz(2:end, 1:4), diff(raw_nz(:, 5))];


%% 6. NEW ZEALAND: LONG-RUN IDENTIFICATION
% -----------------------------------------------------------------------
% Estimate VAR
VAR = VARmodel(y_nz, p, detc, VARopt_LR);

% Same two IRF transformations as §3:
% (a) cumulate RER growth to get level response
% (b) normalize to a 1pp rate rise on impact
IR = VAR.IR;
IR(:,rer_idx, :) = cumsum(IR(:,rer_idx,:),1);   % cumulate
IR = IR./IR(1,mp_idx,mp_idx);                   % normalize

% Extract interest rate and RER responses for plots
nz_lr_rate = squeeze(IR(:, mp_idx,  mp_idx));   % interest rate response
nz_lr_rer  = squeeze(IR(:, rer_idx, mp_idx));   % RER response
disp('New Zealand (long-run) done.')


%% 7. NEW ZEALAND: CHOLESKY IDENTIFICATION
% -----------------------------------------------------------------------
% Ordering 1: i at position 4, RER at position 5 (standard recursive).
VAR = VARmodel(y_nz,p,detc,VARopt_SR);

% Change IRFs
IR = VAR.IR;
IR(:, rer_idx, :) = cumsum(IR(:,rer_idx,:),1); % cumulate RER growth to level
IR = IR./IR(1,mp_idx,mp_idx); % normalize to 1pp rate rise

% Extract interest rate and RER responses for plots
nz_ch1_rate = squeeze(IR(:,mp_idx,mp_idx));   % interest rate response
nz_ch1_rer  = squeeze(IR(:,rer_idx,mp_idx));   % RER response

% Ordering 2: swap positions 4 and 5 so RER precedes i.
% Re-index: RER is now at position 4, rate at position 5.
y_nz_swap = [y_nz(:,1:3), y_nz(:,rer_idx), y_nz(:,mp_idx)];

% Estimate VAR
VAR  = VARmodel(y_nz_swap,p,detc,VARopt_SR);

% Change IRFs
IR = VAR.IR;
IR(:,4,:) = cumsum(IR(:,4,:),1);  % cumulate RER (now at position 4)
IR = IR./IR(1,5,5);               % normalize: rate is now at position 5

% Extract interest rate and RER responses for plots
nz_ch2_rate = squeeze(IR(:,5,5));   % interest rate response
nz_ch2_rer  = squeeze(IR(:,4,5));   % RER response
disp('New Zealand (Cholesky) done.')


%% 8. FIGURE 0: DATA OVERVIEW
% -----------------------------------------------------------------------
% Details for 'DatesPlot'
firstdate = 1982; % Sample starts 1982:Q1
nticks = 6; % Number of years stated on plot
T = size(raw_aus, 1); % Full series length (before lag-trimming)

% Plot
figure; 
FigSize(22, 12)
subplot(2, 2, 1)
    plot(raw_aus(:, 4), '-', 'Color', pantone('Blue'), 'LineWidth', 2); hold on
    DatesPlot(firstdate, T, nticks, 'q')
    title('Australia', 'FontSize', 12)
    ylabel('Interest rate')
    set(gca, 'FontSize', 11); 
    grid on
    SetAxesDual(gca);

subplot(2, 2, 2)
    plot(raw_nz(:, 4), '-', 'Color', pantone('Blue'), 'LineWidth', 2); hold on
    DatesPlot(firstdate, T, nticks, 'q')
    title('New Zealand', 'FontSize', 12)
    set(gca, 'FontSize', 11); 
    grid on
    SetAxesDual(gca);

subplot(2, 2, 3)
    plot(exp(raw_aus(:, 5))*100, '-', 'Color', pantone('Tomato'), 'LineWidth', 2); hold on
    DatesPlot(firstdate, T, nticks, 'q')
    ylabel('RER')
    set(gca, 'FontSize', 11); 
    grid on
    SetAxesDual(gca);

subplot(2, 2, 4)
    plot(exp(raw_nz(:, 5))*100, '-', 'Color', pantone('Tomato'), 'LineWidth', 2); hold on
    DatesPlot(firstdate, T, nticks, 'q')
    set(gca, 'FontSize', 11); 
    grid on
    SetAxesDual(gca);

SaveFigure(fullfile(resdir, 'Figure_0_Data'), 2)
disp('Figure 0 (data) saved.')


%% 9. FIGURE 1: CHOLESKY IRFs (BOTH ORDERINGS)
% -----------------------------------------------------------------------
% Start IRFs at 0
h = 0:hor-1;

figure; 
FigSize(22, 12)
subplot(2, 2, 1)
    h1 = plot(h, aus_ch1_rate, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.5); hold on
    h2 = plot(h, aus_ch2_rate, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    title('Australia', 'FontSize', 12)
    ylabel('Interest rate')
    legend([h1 h2], {'Cholesky (i before RER)', 'Cholesky (RER before i)'}, 'FontSize', 8, 'Location', 'best')
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
subplot(2, 2, 2)
    plot(h, nz_ch1_rate, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.5); hold on
    plot(h, nz_ch2_rate, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    title('New Zealand', 'FontSize', 12)
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
subplot(2, 2, 3)
    plot(h, aus_ch1_rer, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.5); hold on
    plot(h, aus_ch2_rer, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    ylabel('RER')
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
subplot(2, 2, 4)
    plot(h, nz_ch1_rer, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.5); hold on
    plot(h, nz_ch2_rer, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
SaveFigure(fullfile(resdir, 'Figure_1_SR'), 2)
disp('Figure 1 (Cholesky) saved.')

%% 10. FIGURE 2: CHOLESKY + LONG-RUN COMPARISON
% -----------------------------------------------------------------------
figure; 
FigSize(22, 12)
subplot(2, 2, 1)
    h1 = plot(h, aus_ch1_rate, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.0); hold on
    h2 = plot(h, aus_ch2_rate, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    h3 = plot(h, aus_lr_rate,  '-',  'Color', pantone('Pink'),  'LineWidth', 2.5);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    title('Australia', 'FontSize', 12)
    ylabel('Interest rate')
    legend([h1 h2 h3], {'Cholesky (i before RER)', 'Cholesky (RER before i)', 'Long run'}, 'FontSize', 8, 'Location', 'best')
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
subplot(2, 2, 2)
    plot(h, nz_ch1_rate, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.0); hold on
    plot(h, nz_ch2_rate, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot(h, nz_lr_rate,  '-',  'Color', pantone('Pink'),  'LineWidth', 2.5);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    title('New Zealand', 'FontSize', 12)
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
subplot(2, 2, 3)
    plot(h, aus_ch1_rer, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.0); hold on
    plot(h, aus_ch2_rer, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot(h, aus_lr_rer,  '-',  'Color', pantone('Pink'),  'LineWidth', 2.5);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    ylabel('RER')
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
subplot(2, 2, 4)
    plot(h, nz_ch1_rer, '-',  'Color', pantone('Tomato'), 'LineWidth', 2.0); hold on
    plot(h, nz_ch2_rer, '--', 'Color', pantone('Blue'), 'LineWidth', 2.0);
    plot(h, nz_lr_rer,  '-',  'Color', pantone('Pink'),  'LineWidth', 2.5);
    plot([0 hor-1], [0 0], '-k', 'LineWidth', 0.5); xlim([0 hor-1])
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
SaveFigure(fullfile(resdir, 'Figure_2_SR_LR'), 2)
disp('Figure 2 (LR vs Cholesky comparison) saved.')

disp('=== Bjornland (2009) partial replication complete ===')
