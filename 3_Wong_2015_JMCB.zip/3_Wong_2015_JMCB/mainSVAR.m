%% 
% =======================================================================
% Partial replication of results in Wong (2015, JMCB):
% "Do Inflation Expectations Propagate the Inflationary Impact of
%   Real Oil Price Shocks? Evidence from the Michigan Survey"
%
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(50)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot,'VAR'));
addpath(fullfile(toolboxroot,'Figure'));
addpath(fullfile(toolboxroot,'Stats'));
addpath(fullfile(toolboxroot,'Utils'));
addpath(fullfile(toolboxroot,'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

% Data and results folders
datafile = fullfile(fileparts(mfilename('fullpath')), 'Data/data.csv');
resdir   = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir,'dir')
    mkdir(resdir); 
end

%% 1. LOAD AND TRANSFORM DATA
% -----------------------------------------------------------------------
% Columns of data.csv:
% 1 = nominal oil price ($/barrel)
% 2 = CPI level
% 3 = short-run inflation expectations (1-year-ahead)
% 4 = long-run inflation expectations (5-10-year-ahead)
% Sample runs Dec 1982 - Mar 2015; Dec 1982 is used only to form the
% first CPI inflation observation (Jan 1983), making the effective sample
% Jan 1983 - Mar 2015.

% Load data
raw = readmatrix(datafile); % Raw Data

% Transformations
rpo = log(100*(raw(2:end,1)./raw(2:end,2)));   % log real oil price
einflshort = raw(2:end,3);                    % 1yr-ahead expectations
einfllong = raw(2:end,4);                     % 5-10yr-ahead expectations
infl = 1200*diff(log(raw(:,2)));               % annualised m/m CPI inflation

% Specify inputs
p = 12;    % lag length
hor = 16;  % impulse horizon
oilshockpct = 0.1;   % normalise oil shock to a 10% price innovation

vnames = {'Real Oil Price', 'Inflation Expectations', 'Inflation'};
IRFtitles = {'Inflation Expectations', 'CPI Inflation', 'CPI Price Level'};

% Data for two SVARs
dates   = (1983:1/12:2015+2/12)'; % Dates
ind1 = find(abs(dates(:,1) - (1990+3/12)) < 1e-8); % Dates for long-run expectations

y1 = [rpo, einflshort, infl]; % short-run expectations
y2 = [rpo(ind1:end,:) einfllong(ind1:end,:) infl(ind1:end,:)];  % long-run expectations

%% 2. FIGURE 1: DATA PLOT
% -----------------------------------------------------------------------
% Three monthly series: real oil price (level), inflation expectations
% (1yr and 5-10yr on the same panel), and CPI inflation.

% Details for 'DatesPlot'
firstdate = 1983; % Sample starts 1982:M12
nticks = 6;       % Number of dates to display
[T,n] = size(y1); % Number of time periods

% Plot
figure;
FigSize(22, 12)
for ii = 1:n
subplot(1, n, ii)
    plot(y1(:, ii), 'LineWidth', 2, 'Color', pantone('Blue'));
    if ii == 2
    hold on
        plot(einfllong,   'LineWidth', 2, 'Color', pantone('Tomato'));
    hold off
    legend({'1yr ahead', '5--10yr ahead'}, 'FontSize', 10, 'Location', 'northeast')
    end
    title(vnames{ii}, 'FontSize', 12);
    DatesPlot(firstdate, T, nticks, 'm')
    set(gca, 'FontSize', 11); 
    grid on;
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure1_Data'))
disp('Figure 1 (data) saved.')

%% 3. VAR ESTIMATION
% -----------------------------------------------------------------------
VARopt           = VARoption;
VARopt.ident     = 'short';   % Cholesky (recursive) identification
VARopt.nsteps    = hor;       % impulse horizon
VARopt.inference = 1;         % bootstrap confidence intervals
VARopt.ndraws    = 2000;      % number of bootstrap draws
VARopt.pctg      = 68;        % 68% CI (~1 SE)
VARopt.mult      = 500;       % display update every 500 draws
VARopt.vnames    = vnames;    % Variable names

% Short-run model
disp('Estimating 1yr spec VAR, 1983:1--2015:3 ...')
VAR1 = VARmodel(y1, p, 1, VARopt);

% Long-run model
disp('Estimating 5--10yr spec VAR, 1990:4--2015:3 ...')
VAR2 = VARmodel(y2, p, 1, VARopt);

%% 4. 10% OIL PRICE SHOCK NORMALIZATION + CUMULATION OF THE INFLATION RESPONSE
% ---------------------------------------------------------------------------
% Wong does two things outside of the toolbox's capabilities:
%   (a) Shock normalization: considers 10% oil price shock
%   (b) Cumulation: accumulates the inflation response to get the CPI level
% Both are permissible because the SVAR is linear.

% (a) Normalize shock 1 to a 10% oil price shock — OLS estimate uses the
%     scalar scale; each bootstrap draw is normalized by its own impact.
% (b) Append cumulative price level as column n+1 (inflation accumulated
%     and annualised), so §5 and §7 can index it uniformly.

% (a) Short-run model
IR1 = VAR1.IR;    
IR1(:,:,1) = IR1(:,:,1)*oilshockpct/IR1(1,1,1);
IRall1 = VAR1.IRall; 
IRall1(:,:,1,:) = IRall1(:,:,1,:)*oilshockpct./IRall1(1,1,1,:);

% (a) Long-run model
IR2 = VAR2.IR;    
IR2(:,:,1) = IR2(:,:,1)*oilshockpct/IR2(1,1,1);
IRall2 = VAR2.IRall; 
IRall2(:,:,1,:) = IRall2(:,:,1,:)*oilshockpct./IRall2(1,1,1,:);

% (b) Short-run model
IR1CPI = cumsum(IR1(:,3,:),1)/12; % Cumulative sum gives CPI response
IR1CPIall = cumsum(IRall1(:,3,:,:), 1)/12;
IR1 = cat(2,IR1,IR1CPI); % concatenates CPI reponse to final column of IR1
IRall1 = cat(2,IRall1,IR1CPIall);

% (b) Long-run model
IR2CPI = cumsum(IR2(:,3,:),1)/12; % Cumulative sum gives CPI response
IR2CPIall = cumsum(IRall2(:,3,:,:), 1)/12;
IR2 = cat(2,IR2,IR2CPI);% concatenates CPI reponse to final column of IR2
IRall2 = cat(2, IRall2,IR2CPIall);

%% 5. FIGURE 2: IMPULSE RESPONSES
% -----------------------------------------------------------------------
% Wong starts at h=0 in his plots. We can do the same by specifying:
steps = 0:hor-1; % x-axis

% Get the new 68% bands after tranformations
IRstd1 = squeeze(std(IRall1(:,:,1,:), 0, 4));
IRlo1  = IR1(:,:,1) - IRstd1;
IRhi1  = IR1(:,:,1) + IRstd1;

IRstd2 = squeeze(std(IRall2(:,:,1,:), 0, 4));
IRlo2  = IR2(:,:,1) - IRstd2;
IRhi2  = IR2(:,:,1) + IRstd2;

% Plot
for spec = 1:2
    % Select Model
    if spec == 1
        IR = IR1;  IRlo = IRlo1;  IRhi = IRhi1;
        figname = fullfile(resdir, 'Figure2a_IRF_1yr');
    else
        IR = IR2;  IRlo = IRlo2;  IRhi = IRhi2;
        figname = fullfile(resdir, 'Figure2b_IRF_5yr');
    end

    % Plot
    figure; 
    FigSize(26, 10)
    for ii = 1:3
        subplot(1, 3, ii)
        plot(steps, IR(:,ii+1,1), '-',  'Color', pantone('Blue'), 'LineWidth', 2); hold on
        plot(steps, IRlo(:,ii+1), '--', 'Color', pantone('Blue'), 'LineWidth', 1)
        plot(steps, IRhi(:,ii+1), '--', 'Color', pantone('Blue'), 'LineWidth', 1)
        plot([steps(1) steps(end)], [0 0], '-k', 'LineWidth', 0.5)
        title(IRFtitles{ii}, 'FontSize', 12)
        grid on
        set(gca, 'FontSize', 11)
        SetAxesDual(gca)
    end
    SaveFigure(figname, 2)
end
disp('Figure 2 (impulse responses) saved.')

%% 6. FIGURE 3: OIL SHOCK CONTRIBUTION TO INFLATION EXPECTATIONS
% -----------------------------------------------------------------------
% Historical decomposition: cumulative contribution of the oil price shock
% to the historical path of inflation expectations with a dual y-axis
% 1yr ahead (left) and 5-10yr ahead (right).

HD1 = VAR1.HD.shock(:,1,2);   % short-run exp. infl. explained by oil price
HD2 = VAR2.HD.shock(:,1,2);   % long-run exp. infl. explained by oil price

% Pad the start on the long-run series with NaN values to make same length
% as short-run series
HD2_plot = [nan(ind1-1, 1); HD2];

% Specify different episodes of historical significance
ep_date = [1986, 1990+7/12, 2003, 2008+5/12, 2014+5/12];
ep_name = {'1986 OPEC collapse', 'Iraq invasion of Kuwait', ...
           '2003 price surge',   '2008 Recession', '2014 collapse'};
ep_loc  = [1.3, 1.15, 1.3, 1.3, 1.3];

% Plot
figure('Name','Figure 3: Wong (2015, JMCB) -- oil shock contribution to inflation expectations');
FigSize(30, 10)

[hAx, hLine1, hLine2] = plotyy(dates, HD1, dates, HD2_plot, 'plot');
% Specify settings for short-run line
set(hLine1, 'LineStyle', '-',  'LineWidth', 2.5, 'Color', 'k')
set(get(hAx(1), 'Ylabel'), 'String', '1 yr Ahead',    'FontSize', 14)
set(hAx(1), 'ylim', [-1 1.5],   'ytick', -1:0.5:1.5)
% Specify settings for long-run line
set(hLine2, 'LineStyle', '-.', 'LineWidth', 2.5, 'Color', 'r')
set(get(hAx(2), 'Ylabel'), 'String', '5-10 yr Ahead', 'FontSize', 14)
set(hAx(2), 'ylim', [-0.2 0.3], 'ytick', -0.2:0.1:0.3)
% Specify general settings
title('Cumulative Effect of Real Oil Price Shocks on Inflation Expectations', 'FontSize', 14)
set(hAx, {'ycolor'}, {'k';'k'}, 'FontSize', 14)
set(hAx, 'xlim', [dates(1) dates(end)]);
legend('1 yr ahead', '5-10 yr ahead', 'Location', 'southoutside', 'Orientation', 'horizontal', 'FontSize', 10)

% Add zero line, and episode boundary lines and labels
hold on
    plot([dates(1) dates(end)], [0 0], '-k', 'LineWidth', 1)
    for k = 1:numel(ep_date)
        plot([ep_date(k) ep_date(k)], [-1 2], '-.b', 'LineWidth', 1.5)
        text(ep_date(k) + 0.1, ep_loc(k), ep_name{k}, ...
            'HorizontalAlignment', 'left', 'FontSize', 12, 'FontWeight', 'bold')
    end
hold off

SaveFigure(fullfile(resdir, 'Figure3'))
disp('Figure 3 (HD contribution) saved.')

%% 7. FIGURE 4: COUNTERFACTUAL IRFs
% -----------------------------------------------------------------------
% Following Wong, a sequence of expectations structural shocks (shock 2)
% is used to 'zero out' the expectations response (variable 2) at every horizon.

% Convert toolbox IRF format (hor × n × n) to (n^2 × hor).
% Use only the first n variable columns (col n+1 is the appended cumulative).
IRF_mat1 = zeros(n^2, hor);
IRF_mat2 = zeros(n^2, hor);
for h = 1:hor
    IRF_mat1(:,h) = reshape(squeeze(IR1(h,1:n,:)), n^2, 1);
    IRF_mat2(:,h) = reshape(squeeze(IR2(h,1:n,:)), n^2, 1);
end

% Compute counterfactual IRFs using function from Wong (see end of file)
% response=1: oil shock;  
% shock=2: used to zero out;  
% variable=2: zeroed out.
[C_IRF1, ~] = full_counterfactual_IRF(IRF_mat1, VAR1.B, 1, 2, 2, VAR1.Fcomp);
[C_IRF2, ~] = full_counterfactual_IRF(IRF_mat2, VAR2.B, 1, 2, 2, VAR2.Fcomp);
% C_IRF rows = [oil | expectations | inflation] 

% Cumulative price-level counterfactuals 
cumCF1 = cumsum(C_IRF1(3,:)') / 12;
cumCF2 = cumsum(C_IRF2(3,:)') / 12;

for spec = 1:2
    % Select model
    if spec == 1
        IR = IR1;  IRlo = IRlo1;  IRhi = IRhi1;
        cf = [C_IRF1(2,:)', C_IRF1(3,:)', cumCF1]; % CF1
        figname4 = fullfile(resdir, 'Figure4a_CFirf_1yr');
    else
        IR = IR2;  IRlo = IRlo2;  IRhi = IRhi2;
        cf = [C_IRF2(2,:)', C_IRF2(3,:)', cumCF2]; % CF2
        figname4 = fullfile(resdir, 'Figure4b_CFirf_5yr');
    end

    % Plot
    figure; 
    FigSize(26, 10)
    for ii = 1:3
        subplot(1, 3, ii)
        h_act = plot(steps, IR(:,ii+1,1), '-',  'Color', pantone('Blue'), 'LineWidth', 2); 
        hold on
                plot(steps, IRlo(:,ii+1), '--', 'Color', pantone('Blue'), 'LineWidth', 1)
                plot(steps, IRhi(:,ii+1), '--', 'Color', pantone('Blue'), 'LineWidth', 1)
        h_cf  = plot(steps, cf(:,ii),     '-.k', 'LineWidth', 2);
                plot([steps(1) steps(end)], [0 0], '-k', 'LineWidth', 0.5)
        hold off
        title(IRFtitles{ii}, 'FontSize', 12)
        grid on
        set(gca, 'FontSize', 11)
        if ii == 1
            legend([h_act h_cf], {'Actual', 'Counterfactual'})
        end
        SetAxesDual(gca)
    end
    SaveFigure(figname4, 2)
end
disp('Figure 4 (counterfactual IRFs) saved.')

%% 8. FIGURE 5: GREAT RECESSION EXERCISE
% -----------------------------------------------------------------------
% Counterfactual simulation: how would CPI inflation and expectations have
% evolved from Jan 2009 if oil prices had stayed flat at their Dec 2008
% level? Uses 1yr-ahead spec (VAR1). See local function below.
start_ind  = find(abs(dates(:,1) - 2009) < 1e-8); % Find 2008:M12
y_flat_oil = flat_oil_counterfactual(VAR1, y1, p, start_ind); % Counterfactual
y_actual   = y1(start_ind:end, :); % Actual Values

% Adjust the column order of data to match the plot in Wong (2015)
col_order = [3, 2, 1];

% Details for 'DatesPlot'
firstdateCF = 2009 + 11/12; % Starts 2008:M12 but this gives visually correct result (not sure why!)
nticksCF = 4; % Number of dates to display
TCF = 12*3; % Number of time periods (2008:M12-2011:M12)

% Plot
figure;
FigSize(20, 15)
for ii = 1:3
    subplot(3, 1, ii)
    plot(y_actual(:,col_order(ii)),'-b','LineWidth', 2); 
    hold on
        plot(y_flat_oil(:,col_order(ii)),'-.k','LineWidth', 2)
    hold off
    title(vnames{col_order(ii)}, 'FontSize', 12)
    DatesPlot(firstdateCF, TCF, nticksCF, 'm')
    set(gca, 'FontSize', 11); 
    grid on
    if ii == 3
        ylim([2,4])
        legend({'Actual', 'Counterfactual'},'Location', 'southeast')
    end
    SetAxesDual(gca)
end
SaveFigure(fullfile(resdir, 'Figure5_GreatRecession'), 2)
disp('Figure 5 (Great Recession exercise) saved.')

disp('Done. All figures saved to results/.')

%% LOCAL FUNCTIONS: TAKEN FROM WONG(2015) REPLICATION FILE
% =======================================================================

function y_cf = flat_oil_counterfactual(VAR, y, p, start_ind)
% flat_oil_counterfactual  Simulate a counterfactual path in which oil
%   (variable 1) is held flat at its value on the period before start_ind.
%   All other variables evolve with their actual reduced-form residuals,
%   so only the oil channel is switched off.
%
%   VAR       - VARmodel output struct (uses .B, .Ft, .resid)
%   y         - (nobs × n) data matrix used to estimate VAR
%   p         - lag order
%   start_ind - row of y at which to begin the simulation (1-based)
%
%   Returns y_cf (sim_T × n): counterfactual variable paths.

n        = size(y, 2);
invB        = inv(VAR.B);               % VAR.B = chol(sigma,'lower'), set by VARmodel
B_mats      = VAR.Ft(2:end,:)';        % (n × n*p) lag coefficients

% Initial state: p periods ending at start_ind-1, most recent first
y_init = y(start_ind-p : start_ind-1, :);
state  = reshape(flipud(y_init)', [], 1);

% Residuals aligned to start_ind (VAR.resid row j ↔ y row j+p)
Uc    = VAR.resid(start_ind-p : end, :);
sim_T = size(Uc, 1);
y_cf  = zeros(sim_T, n);

for i = 1:sim_T
    temp     = VAR.Ft(1,:)' + B_mats * state + Uc(i,:)';
    % Structural oil shock to offset the predicted oil change (keep oil flat)
    ss_oil   = -(temp(1) - state(1)) / invB(1,1);
    y_cf(i,:) = (temp + invB * [ss_oil; zeros(n-1,1)])';
    % Advance state: prepend counterfactual period, drop oldest lag
    state = [y_cf(i,:)'; state(1:end-n)];
end
end


function [C_IRF, counterfactual_shocks] = full_counterfactual_IRF(IRF, A_0_inv, response, shock, variable, Companion)
% full_counterfactual_IRF  Counterfactual IRF: zero out one variable's
%   response to a given shock by adding a sequence of shocks to another
%   variable at every horizon.
%
%   IRF       (M^2 × nhor)  vectorised IRF matrix; rows are stacked
%             column-by-column from the (M × M) IRF matrix at each horizon,
%             so rows 1:M correspond to responses to shock 'response'.
%   A_0_inv   (M × M)       structural impact matrix (lower Cholesky).
%   response  scalar         shock whose IRF is to be modified (e.g. 1 = oil).
%   shock     scalar         shock index used as the counterfactual instrument
%                            (e.g. 2 = expectations shock).
%   variable  scalar         variable index to zero out (e.g. 2 = expectations).
%   Companion (M*p × M*p)   VAR companion matrix.
%
%   Based on Wong (2015, JMCB) -- B. Wong, CAMA/ANU, Sept 2013

M   = size(A_0_inv, 1);
p   = size(Companion, 1) / M;
hor = size(IRF, 2);

counterfactual_shocks = zeros(1, hor);
ss_temp               = zeros(M, hor);
C_IRF                 = zeros(M, hor);

% Extract rows for the selected shock ('response')
IRF = IRF((response-1)*M+1 : response*M, :);

% Selection matrix: extracts the top (M × M) block of the companion state
bigeye = [eye(M) zeros(M, M*(p-1))];

% Impact period (horizon 1)
counterfactual_shocks(1) = -IRF(variable, 1) / A_0_inv(variable, shock);
ss_temp(shock, 1)        = counterfactual_shocks(1);
C_IRF(:, 1)              = IRF(:, 1) + A_0_inv * ss_temp(:, 1);

% Subsequent horizons
for i = 2:hor
    % Accumulated effect of all previous counterfactual shocks at horizon i
    accum = zeros(M, 1);
    for j = 1:i-1
        accum = accum + bigeye * Companion^j * bigeye' * A_0_inv * ss_temp(:, i-j);
    end
    % New counterfactual shock that zeros out the residual expectations response
    counterfactual_shocks(i) = (-IRF(variable, i) - accum(variable)) / A_0_inv(variable, shock);
    ss_temp(shock, i)        = counterfactual_shocks(i);
    % Total additional effect = propagated (accum) + impact of new shock
    accum       = A_0_inv * ss_temp(:, i) + accum;
    C_IRF(:, i) = IRF(:, i) + accum;
end
end