% =======================================================================
% Partial replication of results in Wong (2015, JMCB):
% "Do Inflation Expectations Propagate the Inflationary Impact of
%   Real Oil Price Shocks? Evidence from the Michigan Survey"
%
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(50)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot,'VAR'));
addpath(fullfile(toolboxroot,'Figure'));
addpath(fullfile(toolboxroot,'Stats'));
addpath(fullfile(toolboxroot,'Utils'));
addpath(fullfile(toolboxroot,'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

% Data and results folders
datafile = fullfile(fileparts(mfilename('fullpath')), 'Data/data.csv');
resdir   = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir,'dir')
    mkdir(resdir); 
end

%% 1. LOAD AND TRANSFORM DATA
% -----------------------------------------------------------------------
% Columns of data.csv:
% 1 = nominal oil price ($/barrel)
% 2 = CPI level
% 3 = 1-year-ahead expectations
% 4 = 5-10-year-ahead expectations
% Sample runs Dec 1982 - Mar 2015; Dec 1982 is used only to form the
% first CPI inflation observation (Jan 1983), making the effective sample
% Jan 1983 - Mar 2015.

% Dates
dates   = (1983:1/12:2015+2/12)';

% Data
raw     = readmatrix(datafile);

% Transformations
realoil = log(100*(raw(2:end,1)./raw(2:end,2)));   % log real oil price
exp1yr  = raw(2:end,3);                             % 1yr-ahead expectations
exp5yr  = raw(2:end,4);                             % 5-10yr-ahead expectations
cpiinfl = 1200*diff(log(raw(:,2)));                 % annualised m/m CPI inflation

data_all = [dates realoil exp1yr exp5yr cpiinfl];   % [date oil 1yr 5-10yr cpi]

% Start of 5-10yr expectations sample (April 1990)
ind1 = find(abs(data_all(:,1) - (1990+3/12)) < 1e-8);

% SVAR parameters
p           = 12;    % lag length (matches Wong 2015)
hor         = 16;    % IRF horizon (months)
oilshockpct = 0.1;   % normalise oil shock to a 10% price innovation


%% 2. FIGURE 1: DATA PLOT
% -----------------------------------------------------------------------
% Three monthly series: real oil price (level), inflation expectations
% (1yr and 5-10yr on the same panel), and CPI inflation.

nobs      = size(data_all, 1);   % 387 monthly observations
firstdate = data_all(1, 1);      % 1983.0

% NaN-pad 5-10yr expectations before April 1990
exp5yr_plot = NaN(nobs, 1);
exp5yr_plot(ind1:end) = data_all(ind1:end, 4);

figure;
FigSize(22, 10)

subplot(1, 3, 1)
plot(exp(data_all(:,2)), 'LineWidth', 2, 'Color', pantone('Blue'))
title('\textbf{Real Oil Price}', 'FontSize', 12)
DatesPlot(firstdate, nobs, 6, 'm')
set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
SetAxesDual(gca)
yyaxis right; yticklabels({}); yyaxis left

subplot(1, 3, 2)
plot(data_all(:,3), 'LineWidth', 2, 'Color', pantone('Blue')); hold on
plot(exp5yr_plot,   'LineWidth', 2, 'Color', pantone('Tomato'))
title('\textbf{Inflation Expectations}', 'FontSize', 12)
legend({'1yr ahead', '5--10yr ahead'}, 'FontSize', 10, 'Location', 'northeast')
DatesPlot(firstdate, nobs, 6, 'm')
set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
SetAxesDual(gca)
yyaxis right; yticklabels({}); yyaxis left

subplot(1, 3, 3)
plot(data_all(:,5), 'LineWidth', 2, 'Color', pantone('Blue'))
title('\textbf{CPI Inflation}', 'FontSize', 12)
DatesPlot(firstdate, nobs, 6, 'm')
set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on
SetAxesDual(gca)
yyaxis right; yticklabels({}); yyaxis left

SaveFigure(fullfile(resdir, 'Figure1_Data'))
disp('Figure 1 (data) saved.')


%% 3. VAR ESTIMATION
% -----------------------------------------------------------------------
VARopt           = VARoption;
VARopt.ident     = 'short';   % Cholesky (recursive) identification
VARopt.nsteps    = hor;       % impulse horizon
VARopt.inference = 1;         % bootstrap confidence intervals
VARopt.ndraws    = 2000;      % number of bootstrap draws
VARopt.pctg      = 68;        % 68% CI (≈ ±1 SE)
VARopt.mult      = 500;       % display update every 500 draws
VARopt.vnames    = {'Real Oil Price','Inflation Expectations','CPI Inflation'};

% Spec 1: 1-year-ahead expectations (Jan 1983 - Mar 2015)
y1 = [data_all(:,2)        data_all(:,3)        data_all(:,5)];   % oil | 1yr | cpi
disp('Estimating 1yr spec VAR, 1983:1--2015:3 ...')
VAR1 = VARmodel(y1, p, 1, VARopt);

% Spec 2: 5-10-year-ahead expectations (Apr 1990 - Mar 2015)
y2 = [data_all(ind1:end,2) data_all(ind1:end,4) data_all(ind1:end,5)];  % oil | 5yr | cpi
disp('Estimating 5--10yr spec VAR, 1990:4--2015:3 ...')
VAR2 = VARmodel(y2, p, 1, VARopt);

nvar = size(y1, 2);   % number of variables (= 3)


%% 4. NORMALISATION TO A 10% OIL PRICE SHOCK
% -----------------------------------------------------------------------
% Rescale oil price shock to a 10% shock as in the paper

scale1 = oilshockpct / VAR1.IR(1,1,1);
IR1    = VAR1.IR;    IR1(:,:,1)      = IR1(:,:,1)      * scale1;
IRinf1 = VAR1.IRinf; IRinf1(:,:,1)   = IRinf1(:,:,1)   * scale1;
IRsup1 = VAR1.IRsup; IRsup1(:,:,1)   = IRsup1(:,:,1)   * scale1;
IRall1 = VAR1.IRall; IRall1(:,:,1,:) = IRall1(:,:,1,:) * scale1;

scale2 = oilshockpct / VAR2.IR(1,1,1);
IR2    = VAR2.IR;    IR2(:,:,1)      = IR2(:,:,1)      * scale2;
IRinf2 = VAR2.IRinf; IRinf2(:,:,1)   = IRinf2(:,:,1)   * scale2;
IRsup2 = VAR2.IRsup; IRsup2(:,:,1)   = IRsup2(:,:,1)   * scale2;
IRall2 = VAR2.IRall; IRall2(:,:,1,:) = IRall2(:,:,1,:) * scale2;


%% 5. FIGURE 2: IMPULSE RESPONSES
% -----------------------------------------------------------------------
% Wong (2015) accumulates the CPI inflation response to recover the price
% level and plots Inflation Expectations, CPI Inflation, & CPI Price Level.

oilshock_var = 1;   % oil price shock (variable 1 in the ordering)
var_exp      = 2;   % inflation expectations
var_cpi      = 3;   % CPI inflation

% Cumulative price-level IRF and 1 SD bands
cumIR1     = cumsum(IR1(:, var_cpi, oilshock_var), 1);
cumIR1_std = squeeze(std(cumsum(IRall1(:, var_cpi, oilshock_var, :), 1), 0, 4));
cumIR1_lo  = cumIR1 - cumIR1_std;
cumIR1_hi  = cumIR1 + cumIR1_std;

cumIR2     = cumsum(IR2(:, var_cpi, oilshock_var), 1);
cumIR2_std = squeeze(std(cumsum(IRall2(:, var_cpi, oilshock_var, :), 1), 0, 4));
cumIR2_lo  = cumIR2 - cumIR2_std;
cumIR2_hi  = cumIR2 + cumIR2_std;

% Build hor×3×1 display arrays for VARirplot
IR1_disp  = reshape([IR1(:,var_exp,1),    IR1(:,var_cpi,1),    cumIR1/12   ], hor, 3, 1);
INF1_disp = reshape([IRinf1(:,var_exp,1), IRinf1(:,var_cpi,1), cumIR1_lo/12], hor, 3, 1);
SUP1_disp = reshape([IRsup1(:,var_exp,1), IRsup1(:,var_cpi,1), cumIR1_hi/12], hor, 3, 1);

IR2_disp  = reshape([IR2(:,var_exp,1),    IR2(:,var_cpi,1),    cumIR2/12   ], hor, 3, 1);
INF2_disp = reshape([IRinf2(:,var_exp,1), IRinf2(:,var_cpi,1), cumIR2_lo/12], hor, 3, 1);
SUP2_disp = reshape([IRsup2(:,var_exp,1), IRsup2(:,var_cpi,1), cumIR2_hi/12], hor, 3, 1);

% VARopt settings for VARirplot
VARopt.pick       = 1;        % plot shock 1 only (oil); 0 = all shocks
VARopt.hstart     = 0;        % first tick on x-axis (0 = impact period)
VARopt.subplot    = [1, 3];   % subplot grid: 1 row, 3 columns
VARopt.figsize    = [22, 10]; % figure width × height in cm
VARopt.latex      = 1;        % render text with LaTeX interpreter
VARopt.shorttitle = 1;        % panel title = variable name only (omit shock name)
VARopt.grid       = 1;        % show grid lines on each panel
VARopt.quality    = 2;        % save quality: 2 = exportgraphics (R2020a+)
VARopt.vnames     = {'Inflation Expectations', 'CPI Inflation', 'CPI Price Level'};


% Spec 1: 1-year-ahead (1983:1--2015:3)
VARopt.figname = fullfile(resdir, 'Figure2a_IRF_1yr');
VARirplot(IR1_disp, VARopt, INF1_disp, SUP1_disp);

% Spec 2: 5-10-year-ahead (1990:4--2015:3)
VARopt.figname = fullfile(resdir, 'Figure2b_IRF_5yr');
VARirplot(IR2_disp, VARopt, INF2_disp, SUP2_disp);

disp('Figure 2 (impulse responses) saved.')


%% 6. FIGURE 3: OIL SHOCK CONTRIBUTION TO INFLATION EXPECTATIONS
% -----------------------------------------------------------------------
% Historical decomposition: cumulative contribution of the oil price shock
% to the historical path of inflation expectations.
% Dual y-axis: 1yr ahead (left) and 5-10yr ahead (right).

HD1 = VAR1.HD.shock(:,1,2);   % 1yr spec
HD2 = VAR2.HD.shock(:,1,2);   % 5yr spec

% Align the shorter 5yr series on the same date axis (NaN-pad the start)
HD2_plot = [nan(size(HD1,1)-size(HD2,1), 1); HD2];

figure('Name','Figure 3: Wong (2015, JMCB) -- oil shock contribution to inflation expectations');
FigSize(30, 10)

[hAx, hLine1, hLine2] = plotyy(data_all(:,1), HD1, data_all(:,1), HD2_plot, 'plot');
set(hLine1, 'LineStyle', '-',  'LineWidth', 2.5, 'Color', 'k')
set(hLine2, 'LineStyle', '-.', 'LineWidth', 2.5, 'Color', 'r')
set(hAx, {'ycolor'}, {'k';'k'}, 'FontSize', 14)
title('Cumulative Effect of Real Oil Price Shocks on Inflation Expectations', 'FontSize', 14)
set(hAx, 'xlim', [data_all(1,1) data_all(end,1)]);
set(get(hAx(1), 'Ylabel'), 'String', '1 yr Ahead',    'FontSize', 14)
set(get(hAx(2), 'Ylabel'), 'String', '5-10 yr Ahead', 'FontSize', 14)
set(hAx(1), 'ylim', [-1 1.5],   'ytick', -1:0.5:1.5)
set(hAx(2), 'ylim', [-0.2 0.3], 'ytick', -0.2:0.1:0.3)
legend('1 yr ahead', '5-10 yr ahead', 'Location', 'southoutside', 'Orientation', 'horizontal', 'FontSize', 10)

% Zero line, episode boundary lines, and episode labels
ep_x = [1986, 1990+7/12, 2003, 2008+5/12, 2014+5/12];
ep_lbl = {'1986 OPEC collapse', 'Iraq invasion of Kuwait', ...
           '2003 price surge',   '2008 Recession', '2014 price collapse'};
y_lbl  = [1.3, 1.15, 1.3, 1.3, 1.3];

axes(hAx(1)); hold on
plot([data_all(1,1) data_all(end,1)], [0 0], '-k', 'LineWidth', 1)
for k = 1:numel(ep_x)
    plot([ep_x(k) ep_x(k)], [-1 2], '-.b', 'LineWidth', 1.5)
    text(ep_x(k) + 0.1, y_lbl(k), ep_lbl{k}, ...
        'HorizontalAlignment', 'left', 'FontSize', 12, 'FontWeight', 'bold')
end

SaveFigure(fullfile(resdir, 'Figure3'))
disp('Figure 3 (HD contribution) saved.')

%% 7. FIGURE 4: COUNTERFACTUAL IRFs
% -----------------------------------------------------------------------
% Following Wong (2015), a sequence of expectations structural shocks (shock 2)
% is used to 'zero out' the expectations response (variable 2) at every horizon.

% Convert toolbox IRF format (hor × nvar × nvar) to (nvar^2 × hor).
IRF_mat1 = zeros(nvar^2, hor);
IRF_mat2 = zeros(nvar^2, hor);
for h = 1:hor
    IRF_mat1(:,h) = reshape(squeeze(IR1(h,:,:)), nvar^2, 1);
    IRF_mat2(:,h) = reshape(squeeze(IR2(h,:,:)), nvar^2, 1);
end

% Compute counterfactual IRFs (local function defined at end of this file)
% response=1: oil shock;  shock=2: used to zero out;  variable=2: zeroed
[C_IRF1, ~] = full_counterfactual_IRF(IRF_mat1, VAR1.B, 1, 2, 2, VAR1.Fcomp);
[C_IRF2, ~] = full_counterfactual_IRF(IRF_mat2, VAR2.B, 1, 2, 2, VAR2.Fcomp);
% C_IRF is (nvar × hor): rows = [oil | expectations | CPI] counterfactual responses

% Cumulative price-level counterfactuals (annualised to match Figure 2)
cumCF1 = cumsum(C_IRF1(3,:)') / 12;
cumCF2 = cumsum(C_IRF2(3,:)') / 12;

% Plot inputs: I couldn't do this directly in Toolbox so pulled relevant code out
steps     = VARopt.hstart : 1 : VARopt.hstart + hor - 1;
cf_titles = {'\textbf{Inflation Expectations}', '\textbf{CPI Inflation}', '\textbf{CPI Price Level}'};

SwatheOpt = PlotSwatheOption; % Used in VARirplot.m but put here for flexibility
SwatheOpt.swathecol  = pantone('Blue');
SwatheOpt.swatheonly = 1;
SwatheOpt.transp     = 1;
SwatheOpt.alpha      = 0.15;
SwatheOpt.border     = 1;
SwatheOpt.xvec       = steps;

for spec = 1:2
    if spec == 1 % 1 year expectations
        pt = IR1_disp;  lo = INF1_disp;  hi = SUP1_disp;
        cf = {C_IRF1(2,:)', C_IRF1(3,:)', cumCF1};
        figname4 = fullfile(resdir, 'Figure4a_CFirf_1yr');
    else % 10 year expectations
        pt = IR2_disp;  lo = INF2_disp;  hi = SUP2_disp;
        cf = {C_IRF2(2,:)', C_IRF2(3,:)', cumCF2};
        figname4 = fullfile(resdir, 'Figure4b_CFirf_5yr');
    end

    figure;
    FigSize(20, 15)
    for ii = 1:nvar
        subplot(1, nvar, ii)
        PlotSwathe(pt(:,ii,1), [lo(:,ii,1) hi(:,ii,1)], SwatheOpt); hold on
        h_act = plot(steps, pt(:,ii,1), '-',   'Color', pantone('Blue'), 'LineWidth', 2); hold on
        h_cf  = plot(steps, cf{ii},     '-.k', 'LineWidth', 2); hold on
        plot(steps, zeros(hor,1), '-k', 'LineWidth', 0.5)
        xlim([steps(1) steps(end)])
        title(cf_titles{ii}, 'FontSize', 14, 'Interpreter', 'latex')
        set(gca, 'FontSize', 12, 'Layer', 'bottom', 'TickLabelInterpreter', 'latex'); grid on
        if ii == 1
            legend([h_act h_cf], {'Actual', 'Counterfactual'}, ...
                'FontSize', 10, 'Interpreter', 'latex', 'Location', 'best')
        end
        SetAxesDual(gca)
    end
    set(findall(gcf, '-property', 'FontName'), 'FontName', 'Palatino')
    SaveFigure(figname4, 2)
end
disp('Figure 4 (counterfactual IRFs) saved.')


%% 8. FIGURE 5: GREAT RECESSION EXERCISE
% -----------------------------------------------------------------------
% Counterfactual simulation: how would CPI inflation and expectations have
% evolved from Jan 2009 if oil prices had stayed flat at their Dec 2008
% level? Uses 1yr-ahead spec (VAR1). See local function below.

start_ind  = find(abs(data_all(:,1) - 2009) < 1e-8);
y_flat_oil = flat_oil_counterfactual(VAR1, y1, p, start_ind);
sim_length = size(y_flat_oil, 1);
y_actual   = y1(start_ind:start_ind+sim_length-1, :);

% x-axis: monthly data from Jan 2009; Jan of each year = index 1, 13, 25, 37
gr_xtick = [1 13 25 37];
gr_xlab  = {'2009','2010','2011','2012'};
gr_xlim  = [0 49];   % show Jan 2009 through Dec 2012

figure;
FigSize(20, 15)

subplot(3, 1, 1)
plot(y_actual(:,3),   '-',   'Color', pantone('Blue'), 'LineWidth', 2); hold on
plot(y_flat_oil(:,3), '-.k', 'LineWidth', 2)
title('\textbf{CPI Inflation}', 'FontSize', 14, 'Interpreter', 'latex')
set(gca, 'XTick', gr_xtick, 'XTickLabel', gr_xlab, 'XLim', gr_xlim, ...
    'FontSize', 11, 'Layer', 'bottom'); grid on
SetAxesDual(gca)
yyaxis right; yticklabels({}); yyaxis left

subplot(3, 1, 2)
plot(y_actual(:,2),   '-',   'Color', pantone('Blue'), 'LineWidth', 2); hold on
plot(y_flat_oil(:,2), '-.k', 'LineWidth', 2)
title('\textbf{Inflation Expectations (1yr ahead)}', 'FontSize', 14, 'Interpreter', 'latex')
set(gca, 'XTick', gr_xtick, 'XTickLabel', gr_xlab, 'XLim', gr_xlim, ...
    'FontSize', 11, 'Layer', 'bottom'); grid on
SetAxesDual(gca)
yyaxis right; yticklabels({}); yyaxis left

subplot(3, 1, 3)
plot(y_actual(:,1),   '-',   'Color', pantone('Blue'), 'LineWidth', 2); hold on
plot(y_flat_oil(:,1), '-.k', 'LineWidth', 2)
legend({'Actual', 'Counterfactual'}, 'FontSize', 10, 'Location', 'southeast', 'Interpreter', 'latex')
title('\textbf{Log Real Oil Price}', 'FontSize', 14, 'Interpreter', 'latex')
set(gca, 'XTick', gr_xtick, 'XTickLabel', gr_xlab, 'XLim', gr_xlim, 'YLim', [2 4], ...
    'FontSize', 11, 'Layer', 'bottom'); grid on
SetAxesDual(gca)
yyaxis right; yticklabels({}); yyaxis left

set(findall(gcf, '-property', 'FontName'), 'FontName', 'Palatino')
SaveFigure(fullfile(resdir, 'Figure5_GreatRecession'), 2)
disp('Figure 5 (Great Recession exercise) saved.')

disp('Done. All figures saved to results/.')


%% LOCAL FUNCTIONS
% =======================================================================

function y_cf = flat_oil_counterfactual(VAR, y, p, start_ind)
% flat_oil_counterfactual  Simulate a counterfactual path in which oil
%   (variable 1) is held flat at its value on the period before start_ind.
%   All other variables evolve with their actual reduced-form residuals,
%   so only the oil channel is switched off.
%
%   VAR       - VARmodel output struct (uses .B, .Ft, .resid)
%   y         - (nobs × nvar) data matrix used to estimate VAR
%   p         - lag order
%   start_ind - row of y at which to begin the simulation (1-based)
%
%   Returns y_cf (sim_T × nvar): counterfactual variable paths.

nvar        = size(y, 2);
invB        = inv(VAR.B);               % VAR.B = chol(sigma,'lower'), set by VARmodel
B_mats      = VAR.Ft(2:end,:)';        % (nvar × nvar*p) lag coefficients

% Initial state: p periods ending at start_ind-1, most recent first
y_init = y(start_ind-p : start_ind-1, :);
state  = reshape(flipud(y_init)', [], 1);

% Residuals aligned to start_ind (VAR.resid row j ↔ y row j+p)
Uc    = VAR.resid(start_ind-p : end, :);
sim_T = size(Uc, 1);
y_cf  = zeros(sim_T, nvar);

for i = 1:sim_T
    temp     = VAR.Ft(1,:)' + B_mats * state + Uc(i,:)';
    % Structural oil shock to offset the predicted oil change (keep oil flat)
    ss_oil   = -(temp(1) - state(1)) / invB(1,1);
    y_cf(i,:) = (temp + invB * [ss_oil; zeros(nvar-1,1)])';
    % Advance state: prepend counterfactual period, drop oldest lag
    state = [y_cf(i,:)'; state(1:end-nvar)];
end
end


function [C_IRF, counterfactual_shocks] = full_counterfactual_IRF(IRF, A_0_inv, response, shock, variable, Companion)
% full_counterfactual_IRF  Counterfactual IRF: zero out one variable's
%   response to a given shock by adding a sequence of shocks to another
%   variable at every horizon.
%
%   IRF       (M^2 × nhor)  vectorised IRF matrix; rows are stacked
%             column-by-column from the (M × M) IRF matrix at each horizon,
%             so rows 1:M correspond to responses to shock 'response'.
%   A_0_inv   (M × M)       structural impact matrix (lower Cholesky).
%   response  scalar         shock whose IRF is to be modified (e.g. 1 = oil).
%   shock     scalar         shock index used as the counterfactual instrument
%                            (e.g. 2 = expectations shock).
%   variable  scalar         variable index to zero out (e.g. 2 = expectations).
%   Companion (M*p × M*p)   VAR companion matrix.
%
%   Based on Wong (2015, JMCB) -- B. Wong, CAMA/ANU, Sept 2013

M   = size(A_0_inv, 1);
p   = size(Companion, 1) / M;
hor = size(IRF, 2);

counterfactual_shocks = zeros(1, hor);
ss_temp               = zeros(M, hor);
C_IRF                 = zeros(M, hor);

% Extract rows for the selected shock ('response')
IRF = IRF((response-1)*M+1 : response*M, :);

% Selection matrix: extracts the top (M × M) block of the companion state
bigeye = [eye(M) zeros(M, M*(p-1))];

% Impact period (horizon 1)
counterfactual_shocks(1) = -IRF(variable, 1) / A_0_inv(variable, shock);
ss_temp(shock, 1)        = counterfactual_shocks(1);
C_IRF(:, 1)              = IRF(:, 1) + A_0_inv * ss_temp(:, 1);

% Subsequent horizons
for i = 2:hor
    % Accumulated effect of all previous counterfactual shocks at horizon i
    accum = zeros(M, 1);
    for j = 1:i-1
        accum = accum + bigeye * Companion^j * bigeye' * A_0_inv * ss_temp(:, i-j);
    end
    % New counterfactual shock that zeros out the residual expectations response
    counterfactual_shocks(i) = (-IRF(variable, i) - accum(variable)) / A_0_inv(variable, shock);
    ss_temp(shock, i)        = counterfactual_shocks(i);
    % Total additional effect = propagated (accum) + impact of new shock
    accum       = A_0_inv * ss_temp(:, i) + accum;
    C_IRF(:, i) = IRF(:, i) + accum;
end
end
