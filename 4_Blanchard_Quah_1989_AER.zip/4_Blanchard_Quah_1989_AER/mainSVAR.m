% =======================================================================
% Partial replication of Blanchard and Quah (1989, AER):
% "The Dynamic Effects of Aggregate Demand and Supply Disturbances"
%
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(50)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot, 'VAR'));
addpath(fullfile(toolboxroot, 'Figure'));
addpath(fullfile(toolboxroot, 'Stats'));
addpath(fullfile(toolboxroot, 'Utils'));
addpath(fullfile(toolboxroot, 'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

% Data and results folders
datafile = fullfile(fileparts(mfilename('fullpath')), 'Data', 'BQ1989_Data.xlsx');
resdir   = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir, 'dir'); mkdir(resdir); end


%% 1. LOAD DATA
% -----------------------------------------------------------------------
% BQ1989_Data.xlsx: 
% row 1 = variable names
% row 2 = mnemonics
% rows 3+ = quarterly observations with date string in column 1
% Column 1: GDP growth  (first difference of log real GDP, annualised %)
% Column 2: Unemployment rate (level, %)
% Full loaded sample: 1948:Q2 - 1987:Q4. After 8 lags the start is 1950:Q2.

% Load data
raw  = readcell(datafile, 'Sheet', 'Sheet1');
data = cellfun(@double, raw(3:end, 2:end));
y = data;

% Specify inputs
p = 8;    % lag length (BQ 1989, footnote 3, p. 659)
detc = 1;  % Specify a constant is in the model
hor = 40;  % impulse horizon

vnames = raw(1, 2:end);    % long variable names (for plot titles)
mnem   = raw(2, 2:end);    % short mnemonics
snames = {'Supply shock', 'Demand shock'}; % Shock labels

%% 2. FIGURE 1: DATA PLOT
% -----------------------------------------------------------------------
% Details for 'DatesPlot'
firstdate = 1948+1/4;   % Start 1948:Q2
nticks    = 6;          % Number of dates to display
[T, n]    = size(y);    % Number of time periods and variables

% Plot
figure;
FigSize(22, 10)
for ii = 1:n
    subplot(1, n, ii)
    plot(y(:,ii), 'LineWidth', 2, 'Color', pantone('Blue'));
    title(vnames{ii}, 'FontSize', 12);
    DatesPlot(firstdate, T, nticks, 'q')
    set(gca, 'FontSize', 11);
    grid on;
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure1_Data'), 2)
disp('Figure 1 (data) saved.')


%% 3. VAR ESTIMATION AND LONG-RUN IDENTIFICATION
% -----------------------------------------------------------------------
VARopt           = VARoption;
VARopt.ident     = 'long';    % Long-run zero restrictions (Blanchard-Quah)
VARopt.nsteps    = hor;       % IRF horizon in quarters
VARopt.inference = 1;         % Bootstrap confidence bands
VARopt.ndraws    = 2000;      % Number of bootstrap draws
VARopt.mult      = 500;       % Display bootstrap progress every 500 draws
VARopt.pctg      = 68;        % 68% CI (~1 SE), as in BQ (1989)
VARopt.vnames    = vnames;    % Variable labels for plot titles
VARopt.snames    = snames;    % Shock labels for plot titles
VARopt.shorttitle = 1;        % Show variable name only (suppress 'to [shock]')
VARopt.figsize    = [22, 6];  % Width x height (cm) per IRF figure

disp('Estimating VAR and applying long-run identification ...')
VAR = VARmodel(y, p, detc, VARopt);   % 1 = include a constant

% Cumulative Long-run Matrix
A_big = inv(eye(length(VAR.Fcomp)) - VAR.Fcomp); % Entire companion form
A1    = A_big(1:n, 1:n); % Extract nxn component for multiplication with Sigma
C     = chol(A1*VAR.sigma*A1')';
disp(C)

% Short-run Impact Matrix
B0inv = VAR.B; % Alternatively A1\C as in slides
disp(B0inv)

%% 4. FIGURE 2: IRF PANELS -- SUPPLY AND DEMAND SHOCKS
% -----------------------------------------------------------------------
% (a) Supply shock
VARopt.pick    = 1; % responses to shock 1 (supply)
VARopt.figname = fullfile(resdir, 'Figure2a_IRF_Supply');
VARirplot(VAR.IRbar, VARopt, VAR.IRinf, VAR.IRsup);
disp('Figure 2a (supply shock IRFs) saved.')

% (b) Demand shock
VARopt.pick    = 2; % responses to shock 2 (demand)
VARopt.figname = fullfile(resdir, 'Figure2b_IRF_Demand');
VARirplot(VAR.IRbar, VARopt, VAR.IRinf, VAR.IRsup);
disp('Figure 2b (demand shock IRFs) saved.')

%% 5. SIGN NORMALIZATION + CUMULATION OF THE GDP GROWTH RESPONSE
% BQ do two things outside of the toolbox's capabilities:
%   (a) Shock normalization: Demand shock raises output and lowers
%   unemployment. We get the opposite so flip the sign to match their figure. 
%   (b) Cumulation: Cumulates the GDP growth response to get the GDP level
% Both are permissible because the SVAR is linear.

% Responses to supply shock
IRGDP_Supply = cumsum(VAR.IR(:, 1, 1));
IRu_Supply = VAR.IR(:, 2, 1);

% Responses to demand shock
IRGDP_Demand = cumsum(-VAR.IR(:, 1, 2));
IRu_Demand = -VAR.IR(:, 2, 2);

%% 6. FIGURE 3: REPLICATION OF BQ (1989) FIGURE 2
% -----------------------------------------------------------------------
figure; 
FigSize(22, 10)
subplot(1, 2, 1)
    plot(IRGDP_Supply, 'LineWidth', 2.5, 'Color', pantone('Blue'))
    hold on
    plot(IRu_Supply, 'LineWidth', 2.5, 'Color', pantone('Tomato'))
    plot(zeros(VARopt.nsteps, 1), '--k', 'LineWidth', 0.8)
    title('\textbf{Supply shock}', 'FontSize', 14, 'Interpreter', 'latex')
    set(gca, 'Layer', 'bottom', 'FontSize', 12, 'TickLabelInterpreter', 'latex'); grid on

subplot(1, 2, 2)
    plot(IRGDP_Demand, 'LineWidth', 2.5, 'Color', pantone('Blue'))
    hold on
    plot(IRu_Demand, 'LineWidth', 2.5, 'Color', pantone('Tomato'))
    plot(zeros(VARopt.nsteps, 1), '--k', 'LineWidth', 0.8)
    title('\textbf{Demand shock}', 'FontSize', 14, 'Interpreter', 'latex')
    legend({'GDP Level', 'Unemployment'}, 'FontSize', 11, 'Location', 'southeast', 'Interpreter', 'latex')
    set(gca, 'Layer', 'bottom', 'FontSize', 12, 'TickLabelInterpreter', 'latex'); grid on

SaveFigure(fullfile(resdir, 'Figure3_BQ_Fig2'), 2)
disp('Figure 3 (BQ Fig 2 replication) saved.')