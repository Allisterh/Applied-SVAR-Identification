% Estimate_SVAR_ACB_Toolbox.m
% =======================================================================
% Stock and Watson (2001, JEP), "Vector Autoregressions"
% Replication using the ACB VAR Toolbox (Ambrogio Cesa-Bianchi).
%
% MODEL
%   3-variable quarterly VAR, 4 lags, constant.
%   Ordering (Cholesky): [Inflation, Unemployment, Fed Funds Rate].
%
% TOOLBOX FUNCTIONS USED  (ACB VAR Toolbox 4.0)
%   VARoption, VARmodel  -- VAR estimation with bootstrap inference
%   VARprint             -- OLS coefficient table
%   VARvdplot            -- FEVD bar chart
%   VARhd                -- Historical decomposition
%
% We use the Statistics Toolbox to illustrate Granger Causality
%   fitlm, coefTest
%
% OUTPUTS(figures saved with _ABC_Toolbox suffix for easy comparison)
%   Figure 1: Data plot.
%   Figure 2: IRF with 68% bootstrap band - Replicates SW (2001) Figure 1.
%   Figure 3: FEVD chart at horizons 1,4,8,12 quarters (Extra).
%   Figure 4: Historical decomposition of inflation (Extra).
%   Table 1A: Granger causality p-values - Replicates SW (2001) Table 1A.
%   Table 1B: FEVD at horizons 1,4,8,12  - Replicates SW (2001) Table 1B.
%
% Compare with 'Estimate_SVAR_Econometrics_Toolbox.m' for alternative approach.
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for Applications folder, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(42, 'twister')

%% 0. PATHS
% -----------------------------------------------------------------------
thisFile    = mfilename('fullpath');
appRoot     = fileparts(thisFile);
toolboxRoot = fileparts(fileparts(appRoot));          % VAR-Toolbox-main/
addpath(genpath(fullfile(toolboxRoot, 'Auxiliary')));
addpath(genpath(fullfile(toolboxRoot, 'Figure')));
addpath(genpath(fullfile(toolboxRoot, 'Stats')));
addpath(genpath(fullfile(toolboxRoot, 'Utils')));
addpath(genpath(fullfile(toolboxRoot, 'VAR')));

% Data from the Replic folder (no duplication)
dataFile = fullfile(toolboxRoot, 'Replic', 'SW2001', 'SW2001_Data.xlsx');

% Results folder
resdir = fullfile(appRoot, 'results');
if ~exist(resdir, 'dir'); mkdir(resdir); end

% LaTeX interpreter
set(groot, 'defaultTextInterpreter',          'latex')
set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
set(groot, 'defaultLegendInterpreter',        'latex')

% Helper for bold-epsilon shock labels
bfeps = @(s) ['${\bf \epsilon}_{t}^{\mathrm{' s '}}$'];

%% 1. LOAD DATA
% -----------------------------------------------------------------------
raw    = readcell(dataFile, 'Sheet', 'Sheet1');
X      = cellfun(@double, raw(3:end, 2:end));
vnames = raw(1, 2:end);
mnem   = raw(2, 2:end);
nvar   = length(mnem);
nobs   = size(X, 1);

X = [X(:,2) X(:,1) X(:,3)];  % Re-order inflation and unemployment
vnames = {'Unemployment','Inflation','Fed. Funds Rate'};
mnem = {'unemp', 'infl', 'ff'};

%% 2. FIGURE 1 -- DATA PLOT
% -----------------------------------------------------------------------
% First observation date for DatesPlot
year      = str2double(raw{3,1}(1:4));
quarter   = str2double(raw{3,1}(6));
firstdate = year + (quarter-1)/4;

% Figure
figure;
FigSize(18, 12) % Size of figure in cm (width, height)
for ii = 1:nvar
    subplot(1, 3, ii)
    plot(X(:, ii), 'LineWidth', 3, 'Color', pantone('Blue'));
    title(['\textbf{' vnames{ii} '}'], 'FontWeight', 'bold', 'FontSize', 14);
    DatesPlot(firstdate, nobs, 6, 'q')
    set(gca, 'FontSize', 12, 'Layer', 'bottom'); grid on;
    set(findobj(gca, 'Type', 'line'), 'Clipping', 'off');
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure1_Data_ACBToolbox'))
disp('Figure 1 (data) saved.')

%% 3. REDUCED-FORM VAR (coefficient table)
% -----------------------------------------------------------------------
detc  = 1; % Specify whether a constant is in the model
nlags = 4; % Number of lags

% VAR Options
VARopt        = VARoption; % Create a general VAR option field
VARopt.mnem   = mnem;  % Mneumonics for plotting and tables
VARopt.vnames = mnem;  % Variable names for plotting and tables

% Estimate VAR
VAR           = VARmodel(X, nlags, detc, VARopt);

% Print estimated coefficients
approx = 2;
VARprint(VAR, VARopt, approx);

%% 4. TABLE 1A -- GRANGER CAUSALITY TESTS
% -----------------------------------------------------------------------
% Joint F-test: H0 = all lags of variable ii are zero in equation jj.
% Requires Statistics and Machine Learning Toolbox (fitlm, coefTest).

pval_gc = nan(nvar, nvar);
X_pred  = VAR.X(:, 2:end);      % drop constant; fitlm adds its own intercept

for jj = 1:nvar % For each variable as Y
    mdl = fitlm(X_pred, VAR.Y(:, jj)); % Equation-by-equation OLS
    for ii = 1:nvar % For each variables lag as X
        idx           = ii : nvar : nvar*nlags;   % predictor cols for all lags of var ii
        H             = zeros(nlags, 1 + nvar*nlags); % Null: All lagged coefs = 0
        H(:, 1 + idx) = eye(nlags); % Null: All lagged coefs = 0
        pval_gc(ii, jj) = coefTest(mdl, H); % GC test
    end
end

% Short variable labels for the table (π, u, R)
tbl_labels = {'\pi', 'u', 'R'};

% Print to screen (matches SW Table 1A layout)
fprintf('\nPanel A: Granger-Causality Tests (p-values)\n');
fprintf('%-12s  %8s  %8s  %8s\n', 'Regressor', tbl_labels{:});
fprintf('%s\n', repmat('-', 1, 44));
for ii = 1:nvar
    fprintf('%-12s  %8.2f  %8.2f  %8.2f\n', tbl_labels{ii}, pval_gc(ii,:));
end

% Note: The numbers here differ slightly from the paper, however the
% qualitative conclusions are the same.

%% 5. STRUCTURAL VAR: IRF AND FEVD
% -----------------------------------------------------------------------
% Re-estimate with recursive identification and 68% bootstrap bands.
VARopt.ident     = 'short';   % Recursive (short-run) identification
VARopt.nsteps    = 24;        % Impulse horizon (quarters)
VARopt.ndraws    = 500;       % Bootstrap draws
VARopt.inference = 1;         % Compute bootstrap confidence bands
VARopt.vnames    = vnames;    % Variable names for IRF plot labels
VARopt.firstdate = firstdate; % Start date for x-axis
VARopt.frequency = 'q';       % Quarterly data
VARopt.snames    = {bfeps('u'), bfeps('\pi'), bfeps('i')}; % Shock labels (LaTeX)

VAR = VARmodel(X, nlags, detc, VARopt);

fprintf('SW (2001) VAR estimated: %d obs, %d lags, %d variables.\n', nobs, nlags, nvar);

%% 6. FIGURE 2 -- Replicates SW 2001 Figure 1
% -----------------------------------------------------------------------
VARopt.figname = fullfile(resdir, 'Figure2_IRF_ACBToolbox_Reverse_Order');
VARopt.subplot = [1 3]; % Dimension of figure
VARopt.figsize = [36 12]; % Size of figure
VARopt.grid    = 1; % Add grid lines
VARirplot(VAR.IRbar, VARopt, VAR.IRinf, VAR.IRsup);

%% Alternatively, plot the IRFs as 3x3 output with rows = shocks, columns = variables.
shock_labels = {'Unemployment Shock', 'Inflation Shock', 'Int.\ Rate Shock'};
col   = pantone('Blue');
IRF_T = VARopt.nsteps;
x_h   = (1:IRF_T)';
xp    = [x_h; flipud(x_h)];

figure;
FigSize(24, 18)
for rr = 1:nvar          % row = shock
    for cc = 1:nvar      % col = response variable
        subplot(nvar, nvar, (rr-1)*nvar + cc);

        % 68% band
        patch(xp, [VAR.IRinf(:,cc,rr); flipud(VAR.IRsup(:,cc,rr))], col, ...
              'FaceAlpha', 0.25, 'EdgeColor', 'none'); hold on

        % Median
        plot(x_h, VAR.IRbar(:, cc, rr), '-', 'Color', col, 'LineWidth', 2);

        yline(0, 'k');

        if rr == 1; title(['\textbf{' vnames{cc} '}'], 'FontSize', 13); end
        if cc == 1; ylabel(shock_labels{rr}, 'FontSize', 12, 'FontWeight', 'bold'); end

        xlim([1, IRF_T]);
        set(gca, 'FontSize', 11, 'Layer', 'bottom'); grid on;
        set(findobj(gca, 'Type', 'line'), 'Clipping', 'off');
        SetAxesDual(gca);
    end
end
SaveFigure(fullfile(resdir, 'Figure2_IRF_ACBToolbox_Reverse_Order'))

%% 7. FIGURE 3 -- FEVD CHART
% -----------------------------------------------------------------------
VARopt.figname = fullfile(resdir, 'Figure3_FEVD_ACBToolbox_Reverse_Order');
VARopt.subplot  = [1 3];         % 1x3 layout
VARopt.figsize  = [36 12];       % [width height] in cm — doubled height vs default
VARopt.legloc   = 'northeast';   % Legend location
VARopt.legcols  = 1;             % Legend in one column
VARvdplot(VAR.VDbar, VARopt);    % Plotting FEVD
disp('Figure 3 (FEVD bar chart) saved.')

%% 8. TABLE 1B -- VARIANCE DECOMPOSITION
% -----------------------------------------------------------------------
horizons = [1, 4, 8, 12];

fprintf('\nTable 1B: Forecast Error Variance Decomposition (percent)\n');
for vv = 1:nvar
    fprintf('\nVariance Decomposition of %s:\n', vnames{vv});
    fprintf('%-10s  %10s  %10s  %10s\n', 'Horizon', mnem{:});
    fprintf('%s\n', repmat('-', 1, 44));
    for h = horizons
        fprintf('%-10d  %10.0f  %10.0f  %10.0f\n', h, VAR.VD(h, :, vv));
    end
end

%% 9. FIGURE 4 -- HISTORICAL DECOMPOSITION OF INFLATION
% -----------------------------------------------------------------------
% VARmodel already computes and stores the HD in VAR.HD.
% VAR.HDbar contains the bootstrap mean; VAR.HDinf/HDsup the bands.
% We plot shock contributions only (hd_detc=0).

VARopt.figname  = fullfile(resdir, 'Figure4_HD_ACBToolbox_Reverse_Order');
VARopt.pick     = 0;            % Plot all variables
VARopt.subplot  = [1 3];        % 1x3 layout
VARopt.figsize  = [36 12];      % [width height] in cm — doubled height vs default
VARopt.hd_detc  = 0;            % Shock contributions only (exclude deterministic terms)
VARopt.legloc   = 'northwest';
VARopt.legcols  = 1;

VARhdplot(VAR.HD, VARopt);
disp('Figure 4 (Historical Decomposition 1x3) saved.')